var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var numberArr1 = [10, 20, 30, 40];
var numberArr1;
var numberArr1;
function Average() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
    }
    var sum = 0;
    for (var i = 0; i < args.length; i++) {
        sum += args[i];
    }
    if (args.length > 0)
        return sum / (args.length);
    else
        return sum;
}
var emp1 = { id: 1, name: "Manish", city: "Pune" };
var emp2 = __assign({}, emp1);
emp2.id = 100;
console.log(emp1);
console.log(emp2);
