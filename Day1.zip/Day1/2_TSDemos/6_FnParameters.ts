// function hello(name: string) {
//     console.log("Hello,", name);
// }

// hello("Manish");
// hello("Manish", "Sharma");
// hello();

// Optional Parameters (?)
// function hello(name?: string) {
//     console.log("Hello,", name);
// }

// hello("Manish");
// hello();

// function Add(a?: number, b?: number): number {
//     a = a || 0;
//     b = b || 0;
//     return a + b;
// }

// console.log(Add(2, 3));
// console.log(Add(2));
// console.log(Add());

// Default Parameters
function Add(a = 0, b = 0): number {
    return a + b;
}

console.log(Add(2, 3));
console.log(Add(2));
console.log(Add());
