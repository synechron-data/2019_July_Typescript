// function Show(): void {
//     console.log("Show Completed...");
// }

// Show();

// let f1: void;
// f1 = 123;

// let f2: never;
// f2 = 123;

// let f3: never = (function () {
//     throw new Error("Testing Never...")
// })();

// Fn Declaration
function add1(x: number, y: number): number {
    return x + y;
}

// Fn Expression
const add2 = function (x: number, y: number): number {
    return x + y;
}

var a: number;
a = 10;

var add3: (a: number, b: number) => number;
add3 = function (x: number, y: number): number {
    return x + y;
}

var add4: (a: number, b: number) => number;
add4 = function (x, y) {
    return x + y;
}

var add5: (a: number, b: number) => number;
add5 = (x, y) => {
    return x + y;
}

var add6: (a: number, b: number) => number;
add6 = (x, y) => x + y;

// console.log(add1(2, 3));
// console.log(add2(2, 3));
// console.log(add3(2, 3));
// console.log(add4(2, 3));
// console.log(add5(2, 3));
// console.log(add6(2, 3));

// Use Lambdas as callback functions

var employeeArr = [
    { id: 1, name: "ABC", city: "Pune" },
    { id: 2, name: "XYZ", city: "Mumbai" },
    { id: 3, name: "PQR", city: "Pune" }
];

// function filterFn(item: any, index: number, arr: any[]) {
//     return item.city === "Pune"
// }

// var result1 = employeeArr.filter(filterFn);
// console.log(result1);

// Anonymous Fn

// var result1 = employeeArr.filter(function (item: any, index: number, arr: any[]) {
//     return item.city === "Pune"
// });
// console.log(result1);

// var result1 = employeeArr.filter(function (item, index, arr) {
//     return item.city === "Pune"
// });
// console.log(result1);

// Lambdas
// var result1 = employeeArr.filter((item, index, arr) => {
//     return item.city === "Pune"
// });
// console.log(result1);

var result1 = employeeArr.filter((item, index, arr) => item.city === "Pune");
console.log(result1);