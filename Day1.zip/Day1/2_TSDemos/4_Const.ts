const env = "development";
console.log(env);

if (true) {
    const env = "production";
    console.log(env);
}

const obj = { id: 1, name: "manish" };

console.log(obj);
// obj.id = 100;
// obj = {};
console.log(obj);
