var numberArr1 = [10, 20, 30, 40];
var numberArr1: number[];
var numberArr1: Array<number>;

// Rest Parameters
function Average(...args: number[]) {
    var sum = 0;

    for (let i = 0; i < args.length; i++) {
        sum += args[i];
    }

    if (args.length > 0)
        return sum / (args.length);
    else
        return sum;
}

// console.log(Average());
// console.log(Average(1));
// console.log(Average(1, 2));
// console.log(Average(1, 2, 3, 4, 5));
// console.log(Average(1, 2, 3, 4, 5, 6, 7, 8, 9));

// var arr = [10, 20, 30, 40, 50, 60, 70, 80, 90];
// console.log(Average(...arr));

// console.log(1)
// console.log(1, 2)
// console.log(1, 2, "ABC")

// Array Spread
// var numArr = [10, 20, 30, 40, 50, 60, 70, 80, 90];
// console.log(numArr);
// console.log(...numArr);

// var numArr1 = [10, 20, 30, 40, 50];
// var numArr2 = [60, 70, 80, 90];

// var numArr3 = [...numArr1, ...numArr2];
// console.log(numArr3);

// var numArr4 = [...numArr3, 100, 200];
// console.log(numArr4);

// Object Spread
var emp1 = { id: 1, name: "Manish", city: "Pune" };

// var emp2 = emp1;
var emp2 = { ...emp1 };
emp2.id = 100;

console.log(emp1);
console.log(emp2);
