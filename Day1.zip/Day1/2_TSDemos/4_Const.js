var env = "development";
console.log(env);
if (true) {
    var env_1 = "production";
    console.log(env_1);
}
var obj = { id: 1, name: "manish" };
console.log(obj);
console.log(obj);
