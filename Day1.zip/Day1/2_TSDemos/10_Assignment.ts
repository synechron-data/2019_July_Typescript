// function Reverse(word: string): string[];
// function Reverse(wordArr: string[]): string[];

// function Reverse(strOrarr: any) {
//     if (typeof strOrarr == "string")
//         return strOrarr.split("").reverse();
//     else
//         return [...strOrarr].reverse();
//     // return strOrarr.slice().reverse();
// }

// // console.log(Reverse(10));
// console.log(Reverse("Manish"));
// console.log(Reverse(["PQR", "XYZ", "ABC"]));

// ------------------------------------------------ Type Gurads

// var data: (number | string);
// data = 10;
// data = "ABC";
// data = true;

function Reverse(word: string): string[];
function Reverse(wordArr: string[]): string[];

function Reverse(strOrarr: (string | string[])) {
    if (typeof strOrarr == "string")
        return strOrarr.split("").reverse();
    else
        return strOrarr.slice().reverse();
}

console.log(Reverse("Manish"));
console.log(Reverse(["PQR", "XYZ", "ABC"]));