// var i = 10;
// var i = 20;

// console.log(i);

// var i = 10;
// console.log("Before, i is:", i);

// (function(){
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside, i is:", i);
//     }
// })();

// console.log("After, i is:", i);

// -------------------------------------------- Typescript
// let i = 10;
// let i = 20;

// console.log(i);

// var i = 10;
// console.log("Before, i is:", i);

// for (let i = 0; i < 5; i++) {
//     console.log("Inside, i is:", i);
// }

// console.log("After, i is:", i);

// Hoisting
// i = 10;
// console.log(i);
// var i;

// i = 10;
// console.log(i);
// let i;