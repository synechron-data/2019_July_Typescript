function add1(x, y) {
    return x + y;
}
var add2 = function (x, y) {
    return x + y;
};
var a;
a = 10;
var add3;
add3 = function (x, y) {
    return x + y;
};
var add4;
add4 = function (x, y) {
    return x + y;
};
var add5;
add5 = function (x, y) {
    return x + y;
};
var add6;
add6 = function (x, y) { return x + y; };
var employeeArr = [
    { id: 1, name: "ABC", city: "Pune" },
    { id: 2, name: "XYZ", city: "Mumbai" },
    { id: 3, name: "PQR", city: "Pune" }
];
var result1 = employeeArr.filter(function (item, index, arr) { return item.city === "Pune"; });
console.log(result1);
