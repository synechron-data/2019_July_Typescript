function hello(name) {
    console.log("Hello,", name);
}

hello("Manish");
hello("Manish", "Sharma");
hello();