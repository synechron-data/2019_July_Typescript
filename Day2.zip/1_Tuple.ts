// Tuple - Stores a fixed collection of values of same or varied types, maintaining the sequence
var arr: number[] = [10, 20, 30, 40, 50];

var dataArr: (number | string)[] = [1, "ABC"];
dataArr = ["PQR", 10];
dataArr = ["PQR", "XYZ"];
dataArr = [10, 20, 30];

// Tuple
var dataRow: [number, string] = [1, "Manish"];
// dataRow = ["PQR", 10];
// dataRow = ["PQR", "XYZ"];
// dataRow = [10, 20, 30];
// dataRow = [1, "Manish", 20];