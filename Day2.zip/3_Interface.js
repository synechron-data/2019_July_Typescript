var s1 = { height: 5, width: 5 };
var shapeOne = { height: 10, width: 20 };
