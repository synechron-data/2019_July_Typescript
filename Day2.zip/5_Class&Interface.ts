// interface IPerson {
//     name: string;
//     age: number;
//     greet: (msg: string) => string;
// }

// class Person implements IPerson {
//     name: string;
//     age: number;

//     constructor(n: string, a: number) {
//         this.name = n;
//         this.age = a;
//     }

//     greet(msg: string): string {
//         return "Hello";
//     }
// }

// let p1: IPerson = new Person("Abhijeet", 36);
// console.log(p1.greet("Hi"));

// let p2: IPerson = new Person("Ramkant", 36);
// console.log(p2.greet("Hi"));

// ----------------------------------------------- Multiple Interface Implementation

// interface IPerson {
//     name: string;
//     age: number;
//     greet: (msg: string) => string;
// }

// interface IWork {
//     doWork(): string;
// }

// class Person implements IPerson, IWork {
//     name: string;
//     age: number;

//     constructor(n: string, a: number) {
//         this.name = n;
//         this.age = a;
//     }

//     greet(msg: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am Working";
//     }
// }

// ----------------------------------------------- Interface extends other interface

// interface IPerson {
//     name: string;
//     age: number;
//     greet: (msg: string) => string;
// }

// interface IWork {
//     doWork(): string;
// }

// interface ICustomer extends IPerson {
//     doShopping(): void;
// }

// class Customer implements ICustomer, IWork {
//     name: string;
//     age: number;

//     constructor(n: string, a: number) {
//         this.name = n;
//         this.age = a;
//     }

//     greet(msg: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am Working";
//     }

//     doShopping(): void {
//         console.log("Let's go to mall");
//     }
// }

// let c1: Customer = new Customer("Abhijeet", 36);

// let c2: ICustomer = new Customer("Abhijeet", 36);

// let c3: IPerson = new Customer("Abhijeet", 36);

// let c4: IWork = new Customer("Abhijeet", 36);

// ------------------------------------------------- Interface extend Class

// class Vehicle {
//     constructor(public make: string) { }

//     getMake() {
//         return this.make;
//     }
// }

// class Engine {
//     constructor(public manufacturer: string) { }

//     getManufacturer() {
//         return this.manufacturer;
//     }
// }

// interface IFourWheeler extends Vehicle, Engine { }

// class FourWheeler implements IFourWheeler {
//     public make: string;
//     public manufacturer: string;
    
//     getMake(): string {
//         throw new Error("Method not implemented.");
//     }    
    
//     getManufacturer(): string {
//         throw new Error("Method not implemented.");
//     }
// }