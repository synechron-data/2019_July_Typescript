var arr = [10, 20, 30, 40, 50];
var dataArr = [1, "ABC"];
dataArr = ["PQR", 10];
dataArr = ["PQR", "XYZ"];
dataArr = [10, 20, 30];
var dataRow = [1, "Manish"];
