var customer = { id: "C101", name: "Manish", city: "Pune" };
function getPropertyValue(obj, key) {
    return obj[key];
}
console.log(getPropertyValue(customer, "name"));
console.log(getPropertyValue(customer, "city"));
