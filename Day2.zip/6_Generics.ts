// var arr = new Array<number>();

// class Queue {
//     private data: number[] = [];

//     push(d: number) {
//         this.data.push(d);
//     }

//     pop(): number {
//         return this.data.shift();
//     }
// }

// var q1 = new Queue();
// q1.push(10);
// q1.push(20);
// q1.push(30);

// console.log(q1.pop());
// console.log(q1.pop());
// console.log(q1.pop());

// ---------------------------------

// class Queue {
//     private data: any[] = [];

//     push(d: any) {
//         this.data.push(d);
//     }

//     pop(): any {
//         return this.data.shift();
//     }
// }

// var q1 = new Queue();
// q1.push(10);
// q1.push("ABC");
// q1.push(30);

// console.log(q1.pop());
// console.log(q1.pop());
// console.log(q1.pop());

// -------------------------------------
// class Queue<T> {
//     private data: T[] = [];

//     push(d: T) {
//         this.data.push(d);
//     }

//     pop(): T {
//         return this.data.shift();
//     }
// }

// var q1 = new Queue<number>();
// q1.push(10);
// q1.push(30);
// console.log(q1.pop());
// console.log(q1.pop());

// var q2 = new Queue<string>();
// q2.push("abc");
// q2.push("xyz");
// console.log(q2.pop());
// console.log(q2.pop());

// -------------------------------------- Constraints
// interface ILength {
//     length: number;
// }

// // to constrain this function to work with any and 
// // all types that also have the .length property
// function getLength<T extends ILength>(arg: T) {
//     return arg.length;
// }

// getLength<string>("abc");
// getLength<string[]>(["abc", "xyz"]);
// getLength<number[]>([1, 2, 3, 4, 5]);

// getLength<number>(10);

// Using Type Parameters in Generic Constraint

var customer = { id: "C101", name: "Manish", city: "Pune" };

// function getPropertyValue(obj: any, key: any) {
//     return obj[key];
// }

function getPropertyValue<T, K extends keyof T>(obj: T, key: K) {
    return obj[key];
}

console.log(getPropertyValue(customer, "name"));
console.log(getPropertyValue(customer, "city"));
// console.log(getPropertyValue(customer, "pin"));