// // class Employee {
// //     private _name: string;

// //     // Multiple constructor implementations are not allowed.
// //     // constructor(){
// //     //     this._name = "NA";
// //     // }

// //     // constructor(){
// //     //     this._name = "NA";
// //     // }

// //     constructor(name = "NA") {
// //         this._name = name;
// //     }

// //     // Donot use Lambda as Class Member (Increases Memory Usage)
// //     // getName = () => {
// //     //     return this._name;
// //     // }
// //     getName() {
// //         return this._name;
// //     }

// //     setName(name: string) {
// //         this._name = name;
// //     }
// // }

// // var e1 = new Employee();
// // console.log(e1.getName());
// // e1.setName("Abhijeet");
// // console.log(e1.getName());

// // var e2 = new Employee("Manish");
// // console.log(e2.getName());
// // e2.setName("Ram");
// // console.log(e2.getName());

// // // ----------------------------------- Properties
// // // Properties enable developers to expose private class members and 
// // // to encapsulate the logic of getting or setting that member. 

// // class Employee {
// //     private _name: string;

// //     constructor(name = "NA") {
// //         this._name = name;
// //     }

// //     get EName() {
// //         return this._name;
// //     }

// //     set EName(name: string) {
// //         this._name = name;
// //     }
// // }

// // var e1 = new Employee();
// // console.log(e1.EName);
// // e1.EName = "Abhijeet";
// // console.log(e1.EName);

// // ----------------------------------- Parameter Properties/Members
// // Parameter properties let us create and initialize member variables in one place. 
// // It is a shorthand for creating member variables.

// class Employee {
//     // private _name: string;
//     // private _age: number;

//     // constructor(name = "NA", age = 0) {
//     //     this._name = name;
//     //     this._age = age;
//     // }

//     constructor(private _name = "NA", private _age = 0) { }

//     get EName() {
//         return this._name;
//     }

//     set EName(name: string) {
//         this._name = name;
//     }

//     get EAge() {
//         return this._age;
//     }

//     set EAge(age: number) {
//         this._age = age;
//     }
// }

// var e1 = new Employee();
// console.log(e1.EName);
// console.log(e1.EAge);

// ------------------------------------------ Static Members

// class BankAccount {
//     constructor(private _bankname: string, private _accName: string) { }

//     get BankName(): string {
//         return this._bankname;
//     }

//     get AccountName(): string {
//         return this._accName;
//     }
// }

// var a1 = new BankAccount("ICICI", "Manish");
// console.log("Bank Name: ", a1.BankName);
// console.log("Account Holder Name: ", a1.AccountName);

// var a2 = new BankAccount("ICICI", "Abhijeet");
// console.log("\nBank Name: ", a2.BankName);
// console.log("Account Holder Name: ", a2.AccountName);

// class BankAccount {
//     // private static _bankname: string;
//     private static _bankname = "HDFC";

//     constructor(private _accName: string) { }

//     static set BankName(bname: string) {
//         BankAccount._bankname = bname;
//     }

//     get BankName(): string {
//         return BankAccount._bankname;
//     }

//     get AccountName(): string {
//         return this._accName;
//     }
// }

// // BankAccount.BankName = "ICICI";

// var a1 = new BankAccount("Manish");
// console.log("Bank Name: ", a1.BankName);
// console.log("Account Holder Name: ", a1.AccountName);

// var a2 = new BankAccount("Abhijeet");
// console.log("\nBank Name: ", a2.BankName);
// console.log("Account Holder Name: ", a2.AccountName);

// ---------------------------------------------------------------- Readonly Members

class BankAccount {
    private static _bankname = "HDFC";

    constructor(private readonly _accNumber: number, private _accName: string) { }

    // private readonly _accNumber: number;
    // private _accName: string;

    // constructor(accNumber: number, accName: string) {
    //     this._accNumber = accNumber;
    //     this._accName = accName;
    // }

    static set BankName(bname: string) {
        BankAccount._bankname = bname;
    }

    get BankName(): string {
        return BankAccount._bankname;
    }

    get AccountNumber(): number {
        // this._accNumber = 100;
        return this._accNumber;
    }

    get AccountName(): string {
        return this._accName;
    }
}

var a1 = new BankAccount(1, "Manish");
console.log("Bank Name: ", a1.BankName);
console.log("Account Number: ", a1.AccountNumber);
console.log("Account Holder Name: ", a1.AccountName);

var a2 = new BankAccount(2, "Abhijeet");
console.log("\nBank Name: ", a2.BankName);
console.log("Account Number: ", a2.AccountNumber);
console.log("Account Holder Name: ", a2.AccountName);